
#ifndef DATASET_MNIST_H
#define DATASET_MNIST_H


#include <stdint.h>

#define mnist_DATASET_LEN 1000


// An element of the dataset array
typedef struct {
  uint8_t label_index;
  uint8_t predicted_index;
  float   feature_vec[784];
} mnist_record ;


extern const mnist_record  mnist_dataset[1000];


#endif  // DATASET_MNIST_H
