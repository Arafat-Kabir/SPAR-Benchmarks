
#ifndef MODEL_MLP12_H
#define MODEL_MLP12_H


#include <stdint.h>



// Floating point matrix
typedef struct {
  uint32_t row_cnt;
  uint32_t col_cnt;
  float *elements;       // 2D array of floats
} mlp12_Matrix_fl;


// Floating point vector
typedef struct {
  uint32_t vec_len;
  float *elements;       // 1D array of floats
} mlp12_Vector_fl;


// Trained wieghts as floating point numbers
typedef struct {
  // metadata
  float accuracy;
  char *summary;     // A human-readable string

  // model trained parameters
  mlp12_Matrix_fl   fc1_weight;
  mlp12_Matrix_fl   fc2_weight;
  mlp12_Vector_fl   fc1_bias;
  mlp12_Vector_fl   fc2_bias;

} mlp12_Params_fl;


extern const mlp12_Params_fl  mlp12_trained_params;


#endif  // MODEL_MLP12_H
